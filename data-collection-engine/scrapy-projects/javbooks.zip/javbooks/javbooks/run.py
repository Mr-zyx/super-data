import os

if __name__ == '__main__':
    os.system("scrapy crawl javbooks")
